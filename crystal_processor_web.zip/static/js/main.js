// 添加一些交互效果
document.addEventListener('DOMContentLoaded', function () {
    // 控制自定义平移向量选项的显示
    const useCustomVectorCheckbox = document.getElementById('use_custom_vector');
    const customVectorOptions = document.getElementById('custom_vector_options');
    if (useCustomVectorCheckbox && customVectorOptions) {
        useCustomVectorCheckbox.addEventListener('change', function () {
            if (this.checked) {
                customVectorOptions.style.display = 'block';
            } else {
                customVectorOptions.style.display = 'none';
            }
        });
    }

    // 修改文件上传验证部分
    const fileInput = document.getElementById('file');
    if (fileInput) {
        fileInput.addEventListener('change', function () {
            const file = this.files[0];
            if (file) {
                const fileSize = file.size / 1024 / 1024; // MB
                if (fileSize > 16) {
                    alert('File size cannot exceed 16MB!');
                    this.value = '';
                    return;
                }

                // 如果文件有效，自动计算推荐互穿层数
                if (file.name.toLowerCase().endsWith('.cif')) {
                    // 创建FormData对象
                    const formData = new FormData();
                    formData.append('file', file);

                    // 显示加载状态
                    const submitBtn = document.querySelector('button[type="submit"]');
                    const originalBtnText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Analyzing...';
                    submitBtn.disabled = true;

                    // 发送AJAX请求计算推荐层数
                    fetch('/calculate_recommended', {
                        method: 'POST',
                        body: formData
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.recommended_N) {
                                // 更新输入框值
                                document.getElementById('num_layers').value = data.recommended_N;
                            }
                            // 恢复按钮状态
                            submitBtn.innerHTML = originalBtnText;
                            submitBtn.disabled = false;
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            // 恢复按钮状态
                            submitBtn.innerHTML = originalBtnText;
                            submitBtn.disabled = false;
                        });
                }
            }
        });
    }

    // 增强表单提交处理
    const form = document.getElementById('uploadForm');
    if (form) {
        form.addEventListener('submit', function () {
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;

            // 显示处理多个文件的信息
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing multiple layers...';
            submitBtn.disabled = true;

            // 添加处理进度提示
            const progressDiv = document.createElement('div');
            progressDiv.className = 'alert alert-info mt-3';
            progressDiv.innerHTML = '<i class="fas fa-info-circle me-2"></i>Generating interpenetration structures for layers 2 to recommended number...';
            this.parentNode.appendChild(progressDiv);
        });
    }
});
