# -*- coding: utf-8 -*-
import json
import os
import traceback
import warnings

import numpy as np
from pymatgen.core import Structure, Lattice, PeriodicSite
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.io.cif import CifParser, CifWriter
from scipy.spatial import KDTree
import itertools


class InterpenetrationBuilder:
    """
    互穿结构构建器
    用于生成不同层数的互穿网络结构
    """

    def __init__(self, structure):
        """
        初始化

        Args:
            structure: pymatgen Structure对象，单重结构
        """
        self.original_structure = structure
        self.supercell = None
        self.interpenetrated_structure = None
        self.contracted_structure = None

    def build_supercell(self, scaling_matrix):
        """
        构建超胞

        Args:
            scaling_matrix: 扩胞矩阵，如[[2,0,0],[0,1,0],[0,0,1]]

        Returns:
            Structure: 扩胞后的结构
        """
        self.supercell = self.original_structure.make_supercell(scaling_matrix)
        return self.supercell

    def create_interpenetration(self, num_networks=2, translation_vector=None):
        """
        创建互穿结构

        Args:
            num_networks: 网络层数
            translation_vector: 平移向量(分数坐标)，如果为None则自动计算

        Returns:
            Structure: 互穿结构
        """
        if self.supercell is None:
            self.supercell = self.original_structure

        # 自动计算平移向量（如果未提供）
        if translation_vector is None:
            # 对于2重互穿，通常沿主要扩胞方向平移0.5
            translation_vector = self._calculate_auto_translation(num_networks)
        else:
            translation_vector = np.array(translation_vector)

        # 创建互穿结构
        self.interpenetrated_structure = self.supercell.copy()

        # 添加额外的网络
        for i in range(1, num_networks):
            # 计算当前网络的平移向量
            current_translation = translation_vector * i / num_networks

            for site in self.supercell:
                # 应用平移
                new_coords = site.frac_coords + current_translation
                # 处理周期性边界
                new_coords = new_coords - np.floor(new_coords)

                # 创建新的位点（修复：添加lattice参数）
                new_site = PeriodicSite(
                    site.species,
                    new_coords,
                    self.supercell.lattice,
                    properties=site.properties,
                    skip_checks=True
                )

                # 将新网络添加到结构中
                self.interpenetrated_structure.append(site.species, new_coords)

        return self.interpenetrated_structure

    def _calculate_auto_translation(self, num_networks):
        """
        自动计算平移向量
        """
        # 简单的启发式方法：沿最大扩胞方向平移
        scaling_factors = [
            self.supercell.lattice.abc[i] / self.original_structure.lattice.abc[i]
            for i in range(3)
        ]

        max_axis = np.argmax(scaling_factors)
        translation = np.zeros(3)
        translation[max_axis] = 1.0 / num_networks

        return translation

    def validate_interpenetration(self, min_distance=1.0):
        """
        验证互穿结构的有效性

        Args:
            min_distance: 最小允许的原子间距(A)

        Returns:
            bool: 结构是否有效
            list: 问题原子对列表
        """
        if self.interpenetrated_structure is None:
            raise ValueError("请先创建互穿结构")

        problems = []

        # 使用简单的距离矩阵检查，避免VoronoiNN的复杂性
        try:
            # 获取所有原子的笛卡尔坐标
            coords = self.interpenetrated_structure.cart_coords
            lattice = self.interpenetrated_structure.lattice

            for i in range(len(coords)):
                for j in range(i + 1, len(coords)):
                    # 计算原子间距离（考虑周期性边界）
                    distance = lattice.get_distance_and_image(coords[i], coords[j])[0]

                    if distance < min_distance:
                        problems.append({
                            'atom1': i,
                            'atom2': j,
                            'distance': distance,
                            'species1': self.interpenetrated_structure[i].species_string,
                            'species2': self.interpenetrated_structure[j].species_string
                        })
        except Exception as e:
            warnings.warn(f"距离检查出错: {e}")
            # 回退到简单方法
            for i, site1 in enumerate(self.interpenetrated_structure):
                for j, site2 in enumerate(self.interpenetrated_structure):
                    if j <= i:
                        continue
                    distance = site1.distance(site2)
                    if distance < min_distance:
                        problems.append({
                            'atom1': i,
                            'atom2': j,
                            'distance': distance,
                            'species1': site1.species_string,
                            'species2': site2.species_string
                        })

        is_valid = len(problems) == 0
        return is_valid, problems

    def contract_cell(self, contraction_factors=None):
        """
        收缩晶胞

        Args:
            contraction_factors: 各轴的收缩因子，如[1, 1, 0.5]

        Returns:
            Structure: 收缩后的结构
        """
        if self.interpenetrated_structure is None:
            self.interpenetrated_structure = self.original_structure

        # 寻找原始晶胞
        new_structure = self.interpenetrated_structure.get_primitive_structure()

        self.contracted_structure = new_structure
        return new_structure

    def analyze_symmetry(self, structure=None, tolerance=0.1):
        """
        分析结构对称性

        Args:
            structure: 要分析的结构，如果为None则使用当前结构
            tolerance: 对称性分析容差

        Returns:
            dict: 对称性信息
        """
        if structure is None:
            if self.contracted_structure is not None:
                structure = self.contracted_structure
            elif self.interpenetrated_structure is not None:
                structure = self.interpenetrated_structure
            else:
                structure = self.original_structure

        try:
            sga = SpacegroupAnalyzer(structure, symprec=tolerance)

            symmetry_info = {
                'space_group_symbol': sga.get_space_group_symbol(),
                'space_group_number': sga.get_space_group_number(),
                'crystal_system': sga.get_crystal_system(),
                'lattice_type': sga.get_lattice_type(),
            }
        except Exception as e:
            warnings.warn(f"对称性分析失败: {e}")
            symmetry_info = {
                'space_group_symbol': 'Unknown',
                'space_group_number': 0,
                'crystal_system': 'Unknown',
                'lattice_type': 'Unknown',
            }

        return symmetry_info


def create_interpenetrated_structure(input_structure, num_networks=2, scaling_matrix=None, translation_vector=None):
    """
    创建互穿结构的主要函数

    Args:
        input_structure: 输入CIF对象
        num_networks: 网络层数
        scaling_matrix: 扩胞矩阵
        translation_vector: 自定义平移向量

    Returns:
        dict: 处理结果信息
    """
    try:
        builder = InterpenetrationBuilder(input_structure)

        # 构建超胞
        builder.build_supercell(scaling_matrix)

        # 创建互穿结构
        builder.create_interpenetration(num_networks, translation_vector)

        # 收缩晶胞
        contracted = builder.contract_cell()

        # 分析对称性
        original_symmetry = builder.analyze_symmetry(input_structure)
        final_symmetry = builder.analyze_symmetry(contracted)

        result_info = {
            'num_networks': num_networks,
            'original_symmetry': original_symmetry,
            'final_symmetry': final_symmetry,
            'num_atoms': len(contracted)
        }

        return contracted, result_info

    except Exception as e:
        traceback.print_exc()
        raise Exception(f"构建互穿结构失败: {e}")


def calculation_bonds_optimized(structure, output_cif_path, bond_length_tolerance=0.2):
    """
    优化版本：基于原子间距离和键长标准自动计算化学键
    """

    def determine_bond_type(elem1, elem2, distance, r1, r2):
        """根据元素类型和距离判断键类型"""
        expected_length = r1 + r2
        ratio = distance / expected_length

        if ratio < 0.9:
            return "可能的强键/多重键"
        elif ratio <= 1.1:
            return "标准单键"
        elif ratio <= 1.3:
            return "弱键/长键"
        else:
            return "非常规键"

    lattice = structure.lattice
    num_atoms = len(structure)

    print(f"成功读取结构: {num_atoms}个原子")
    print(f"晶胞参数: a={lattice.a:.3f}, b={lattice.b:.3f}, c={lattice.c:.3f}")

    # 定义元素共价半径
    covalent_radii = {
        "H": 0.32, "He": 0.46, "Li": 1.33, "Be": 1.02, "B": 0.85, "C": 0.75,
        "N": 0.71, "O": 0.63, "F": 0.64, "Ne": 0.67, "Na": 1.55, "Mg": 1.39,
        "Al": 1.26, "Si": 1.16, "P": 1.11, "S": 1.03, "Cl": 0.99, "Ar": 0.96,
        "K": 1.96, "Ca": 1.71, "Sc": 1.48, "Ti": 1.36, "V": 1.34, "Cr": 1.22,
        "Mn": 1.19, "Fe": 1.16, "Co": 1.11, "Ni": 1.10, "Cu": 1.12, "Zn": 1.18,
        "Ga": 1.24, "Ge": 1.21, "As": 1.21, "Se": 1.16, "Br": 1.14, "Kr": 1.17,
    }

    # 优化1：使用KDTree进行快速邻居搜索
    def find_bonds_kdtree(structure, covalent_radii, bond_length_tolerance):
        """使用KDTree快速查找化学键"""
        bonds = []

        # 获取所有原子的笛卡尔坐标
        coords = np.array([site.coords for site in structure])
        elements = [site.species_string for site in structure]

        # 计算最大搜索半径（最大共价半径之和 * 容差）
        max_radius = max(covalent_radii.values()) * 2 * (1 + bond_length_tolerance)

        # 创建KDTree（考虑周期性）
        # 对于周期性系统，我们需要创建镜像原子
        lattice_vectors = lattice.matrix
        points = []
        element_map = []
        index_map = []

        # 生成基本单元和相邻镜像
        for dx, dy, dz in itertools.product([-1, 0, 1], repeat=3):
            translation = np.array([dx, dy, dz])
            for i, (coord, elem) in enumerate(zip(coords, elements)):
                new_coord = coord + translation @ lattice_vectors
                points.append(new_coord)
                element_map.append(elem)
                index_map.append((i, dx, dy, dz))  # 记录原子索引和镜像信息

        points = np.array(points)
        tree = KDTree(points)

        # 只查询原始单元中的原子
        original_indices = [i for i, (_, dx, dy, dz) in enumerate(index_map)
                            if dx == 0 and dy == 0 and dz == 0]

        for orig_idx in original_indices:
            i = index_map[orig_idx][0]  # 原始原子索引
            elem_i = element_map[orig_idx]
            r_i = covalent_radii.get(elem_i, 1.5)

            # 查询半径内的所有邻居
            neighbors = tree.query_ball_point(points[orig_idx], max_radius)

            for neighbor_idx in neighbors:
                if neighbor_idx == orig_idx:
                    continue

                j_orig, dx, dy, dz = index_map[neighbor_idx]
                elem_j = element_map[neighbor_idx]
                r_j = covalent_radii.get(elem_j, 1.5)

                # 避免重复计数：只考虑i < j的原子对
                if i >= j_orig:
                    continue
                # 如果只保留分子内键，跳过所有镜像原子间的键
                if dx != 0 or dy != 0 or dz != 0:
                    continue
                # 计算最大允许键长
                max_bond_length = (r_i + r_j) * (1 + bond_length_tolerance)

                # 计算实际距离
                distance = np.linalg.norm(points[orig_idx] - points[neighbor_idx])

                if 0 < distance <= max_bond_length:
                    bond_type = determine_bond_type(elem_i, elem_j, distance, r_i, r_j)
                    bonds.append({
                        "atom_i": i,
                        "atom_j": j_orig,
                        "element_i": elem_i,
                        "element_j": elem_j,
                        "distance": distance,
                        "bond_type": bond_type,
                        "max_allowed": max_bond_length,
                        "image": (dx, dy, dz)  # 记录来自哪个镜像
                    })

        return bonds

    # 优化2：使用pymatgen内置的邻居查找（更简单的方法）
    def find_bonds_pymatgen(structure, covalent_radii, bond_length_tolerance):
        """使用pymatgen内置方法查找化学键"""
        bonds = []

        # 计算最大搜索半径
        max_radius = max(covalent_radii.values()) * 2 * (1 + bond_length_tolerance) + 0.5

        # 使用pymatgen的邻居查找
        for i, site in enumerate(structure):
            elem_i = site.species_string
            r_i = covalent_radii.get(elem_i, 1.5)

            # 获取所有邻居
            neighbors = structure.get_neighbors(site, max_radius)

            for neighbor, distance, j, image in neighbors:
                if j <= i:  # 避免重复计数
                    continue

                elem_j = neighbor.species_string
                r_j = covalent_radii.get(elem_j, 1.5)
                dx, dy, dz = image
                # 如果只保留分子内键，跳过所有镜像原子间的键
                if dx != 0 or dy != 0 or dz != 0:
                    continue
                max_bond_length = (r_i + r_j) * (1 + bond_length_tolerance)

                if distance <= max_bond_length:
                    bond_type = determine_bond_type(elem_i, elem_j, distance, r_i, r_j)
                    bonds.append({
                        "atom_i": i,
                        "atom_j": j,
                        "element_i": elem_i,
                        "element_j": elem_j,
                        "distance": distance,
                        "bond_type": bond_type,
                        "max_allowed": max_bond_length,
                        "image": image
                    })

        return bonds

    # 根据原子数量选择最优方法
    if num_atoms > 1000:
        print("使用KDTree方法（大体系优化）")
        bonds = find_bonds_kdtree(structure, covalent_radii, bond_length_tolerance)
    else:
        print("使用pymatgen内置方法")
        bonds = find_bonds_pymatgen(structure, covalent_radii, bond_length_tolerance)

    # 输出结果
    print(f"\n找到 {len(bonds)} 个化学键:")
    for bond in bonds[:10]:
        print(f"键 {bond['atom_i']}({bond['element_i']})-{bond['atom_j']}({bond['element_j']}): "
              f"{bond['distance']:.3f} A, 类型: {bond['bond_type']}")

    if len(bonds) > 10:
        print("... (其余键已省略)")

    # 保存结果（使用你原来的save_bond_info函数）
    save_bond_info(structure, bonds, output_cif_path)
    print(f"\n分析完成！共找到 {len(bonds)} 个化学键")

    return {
        "structure": structure,
        "bonds": bonds,
        "num_bonds": len(bonds),
        "bond_length_tolerance": bond_length_tolerance
    }


# 保留你原来的save_bond_info函数（需要稍作修改以处理新的bond格式）
def save_bond_info(structure, bonds, output_path):
    """保存键信息到文件（修改版）"""
    import os
    import json

    # 创建输出目录
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)

    # 创建包含键信息的CIF文件
    with open(output_path, 'w') as f:
        f.write(f"# 包含化学键信息的CIF文件\n")
        f.write(f"# 生成的键数量: {len(bonds)}\n")
        f.write(f"# 原始结构: {structure.formula}\n\n")

        # 写入原始CIF内容
        f.write("data_generated\n")
        f.write(f"_cell_length_a {structure.lattice.a}\n")
        f.write(f"_cell_length_b {structure.lattice.b}\n")
        f.write(f"_cell_length_c {structure.lattice.c}\n")
        f.write(f"_cell_angle_alpha {structure.lattice.alpha}\n")
        f.write(f"_cell_angle_beta {structure.lattice.beta}\n")
        f.write(f"_cell_angle_gamma {structure.lattice.gamma}\n\n")

        f.write("loop_\n")
        f.write("_atom_site_label\n")
        f.write("_atom_site_type_symbol\n")
        f.write("_atom_site_fract_x\n")
        f.write("_atom_site_fract_y\n")
        f.write("_atom_site_fract_z\n")

        for i, site in enumerate(structure):
            elem = site.species_string
            f.write(f"{elem}{i} {elem} {site.frac_coords[0]:.6f} {site.frac_coords[1]:.6f} {site.frac_coords[2]:.6f}\n")

        f.write("\n# 化学键信息\n")
        f.write("loop_\n")
        f.write("_geom_bond_atom_site_label_1\n")
        f.write("_geom_bond_atom_site_label_2\n")
        f.write("_geom_bond_distance\n")
        f.write("_geom_bond_site_symmetry_2\n")

        for bond in bonds:
            f.write(f"{bond['element_i']}{bond['atom_i']} {bond['element_j']}{bond['atom_j']} {bond['distance']:.3f} .\n")

    print(f"修改后的CIF文件已保存到: {output_path}")


if __name__ == '__main__':
    input_file = r"C:\Users\python\Downloads\3D-Salen_COF.cif"  # 替换为实际的CIF文件
    output_file = r"C:\Users\python\Downloads\primitive_interpenetrated_2layers_supercell_2x2x2_3D-Salen_COF.cif"  # 替换为实际的CIF文件
    # reduce_to_primitive_cell(input_file, output_file)

    # 读取CIF文件
    structure_ = Structure.from_file(input_file)
    create_interpenetrated_structure(structure_, output_file)
