import numpy as np
import math
from typing import Tuple, Dict, List
import re


def print_ec(*args):
    # print(*args)
    ...


class COFInterpenetrationCalculator:
    """
    COF材料互穿层数计算器
    基于2009年JACS论文中COF-300的计算方法
    """

    def __init__(self):
        # 理想几何参数表（基于文档中的Table 1）
        self.ideal_geometry_table = {
            1: {'crystal_system': 'cubic', 'space_group': 'Fd3m', 'a_ratio': 4 / math.sqrt(3), 'c_ratio': 1, 'a_c_ratio': 1},
            2: {'crystal_system': 'cubic', 'space_group': 'Pn3m', 'a_ratio': 2 / math.sqrt(3), 'c_ratio': 1, 'a_c_ratio': 1},
            # 对于2n+1类型
            '2n+1': {'crystal_system': 'tetragonal', 'space_group': 'I4₁/amd',
                     'a_ratio': math.sqrt(8) / math.sqrt(3), 'c_ratio': lambda N: 4 / (math.sqrt(3) * N),
                     'a_c_ratio': lambda N: N / math.sqrt(2)},
            # 对于4n类型
            '4n': {'crystal_system': 'tetragonal', 'space_group': 'P4/nbm',
                   'a_ratio': 2 / math.sqrt(3), 'c_ratio': lambda N: 4 / (math.sqrt(3) * N),
                   'a_c_ratio': lambda N: N / 2},
            # 对于4n+2类型
            '4n+2': {'crystal_system': 'tetragonal', 'space_group': 'P4₂/nnm',
                     'a_ratio': 2 / math.sqrt(3), 'c_ratio': lambda N: 4 / (math.sqrt(3) * N),
                     'a_c_ratio': lambda N: N / 2}
        }

    def parse_cif_file(self, cif_file_path: str) -> Dict:
        """
        解析CIF文件，提取晶胞参数
        """
        cell_params = {}

        try:
            with open(cif_file_path, 'r', encoding='utf-8') as file:
                content = file.read()

            # 提取晶胞参数（简化版本，实际应用可能需要更复杂的解析）
            patterns = {
                '_cell_length_a': r'_cell_length_a\s+([\d.]+)',
                '_cell_length_b': r'_cell_length_b\s+([\d.]+)',
                '_cell_length_c': r'_cell_length_c\s+([\d.]+)',
                '_cell_angle_alpha': r'_cell_angle_alpha\s+([\d.]+)',
                '_cell_angle_beta': r'_cell_angle_beta\s+([\d.]+)',
                '_cell_angle_gamma': r'_cell_angle_gamma\s+([\d.]+)',
                '_space_group_name_H-M': r'_space_group_name_H-M\s+\'([^\']+)\''
            }

            for key, pattern in patterns.items():
                match = re.search(pattern, content)
                if match:
                    if key.startswith('_cell_angle'):
                        cell_params[key] = float(match.group(1))
                    elif key == '_space_group_name_H-M':
                        cell_params[key] = match.group(1)
                    else:
                        cell_params[key] = float(match.group(1))

            # 如果没有找到b参数，假设a=b（四方晶系）
            if '_cell_length_b' not in cell_params and '_cell_length_a' in cell_params:
                cell_params['_cell_length_b'] = cell_params['_cell_length_a']

        except Exception as e:
            print_ec(f"解析CIF文件时出错: {e}")
            return {}

        return cell_params

    def calculate_bond_length(self, cell_params: Dict) -> float:
        """
        估算键长（基于COF-300的经验值）
        在实际应用中，这需要从分子结构精确计算
        """
        # 简化估算：基于晶胞参数和拓扑结构
        # COF-300中，键长约为19Å（根据文档）
        if '_cell_length_a' in cell_params:
            # 基于经验公式估算
            estimated_length = cell_params['_cell_length_a'] / 1.15  # 根据文档中的经验关系
            return estimated_length
        return 19.0  # 默认值，基于COF-300

    def calculate_interpenetration_number(self, cell_params: Dict) -> Dict:
        """
        计算互穿层数N
        基于公式 N = 2a/c（文档中的主要方法）
        """
        results = {}

        if not all(k in cell_params for k in ['_cell_length_a', '_cell_length_c']):
            raise ValueError("CIF文件中缺少必要的晶胞参数")

        a = cell_params['_cell_length_a']
        c = cell_params['_cell_length_c']

        # 主要计算方法：N = 2a/c
        N_calculated = 2 * a / c
        N_rounded = round(N_calculated)

        results['calculated_N'] = N_calculated
        results['rounded_N'] = N_rounded
        results['a'] = a
        results['c'] = c
        results['2a/c'] = N_calculated

        # 检查晶系是否符合四方晶系特征
        alpha = cell_params.get('_cell_angle_alpha', 90)
        beta = cell_params.get('_cell_angle_beta', 90)
        gamma = cell_params.get('_cell_angle_gamma', 90)
        b = cell_params.get('_cell_length_b', a)

        is_tetragonal = (abs(a - b) < 0.1 and
                         abs(alpha - 90) < 0.1 and
                         abs(beta - 90) < 0.1 and
                         abs(gamma - 90) < 0.1)

        results['crystal_system_valid'] = is_tetragonal
        results['space_group'] = cell_params.get('_space_group_name_H-M', 'Unknown')

        # 根据N值确定可能的拓扑类型
        if N_rounded % 2 == 1 and N_rounded > 2:  # 2n+1类型
            results['topology_type'] = '2n+1'
            results['expected_space_group'] = 'I4₁/amd'
        elif N_rounded % 4 == 0:  # 4n类型
            results['topology_type'] = '4n'
            results['expected_space_group'] = 'P4/nbm'
        elif N_rounded % 2 == 0 and N_rounded % 4 != 0:  # 4n+2类型
            results['topology_type'] = '4n+2'
            results['expected_space_group'] = 'P4₂/nnm'
        else:
            results['topology_type'] = 'special_case'
            results['expected_space_group'] = '需要进一步分析'

        return results

    def validate_with_ideal_geometry(self, results: Dict) -> Dict:
        """
        使用理想几何参数验证计算结果
        """
        N = results['rounded_N']
        a_exp = results['a']
        c_exp = results['c']

        # 估算键长
        bond_length_estimated = self.calculate_bond_length({'_cell_length_a': a_exp})

        # 根据N值选择理想几何参数
        if N in [1, 2]:
            ideal = self.ideal_geometry_table[N]
            a_ideal = ideal['a_ratio'] * bond_length_estimated
            c_ideal = ideal['c_ratio'] * bond_length_estimated
        else:
            if results['topology_type'] == '2n+1':
                ideal = self.ideal_geometry_table['2n+1']
                a_ideal = ideal['a_ratio'] * bond_length_estimated
                c_ideal = ideal['c_ratio'](N) * bond_length_estimated
            elif results['topology_type'] == '4n':
                ideal = self.ideal_geometry_table['4n']
                a_ideal = ideal['a_ratio'] * bond_length_estimated
                c_ideal = ideal['c_ratio'](N) * bond_length_estimated
            elif results['topology_type'] == '4n+2':
                ideal = self.ideal_geometry_table['4n+2']
                a_ideal = ideal['a_ratio'] * bond_length_estimated
                c_ideal = ideal['c_ratio'](N) * bond_length_estimated
            else:
                # 默认使用2n+1类型
                ideal = self.ideal_geometry_table['2n+1']
                a_ideal = ideal['a_ratio'] * bond_length_estimated
                c_ideal = ideal['c_ratio'](N) * bond_length_estimated

        # 计算误差
        a_error = abs(a_exp - a_ideal) / a_exp * 100
        c_error = abs(c_exp - c_ideal) / c_exp * 100

        validation_results = {
            'bond_length_estimated': bond_length_estimated,
            'a_ideal': a_ideal,
            'c_ideal': c_ideal,
            'a_error_percent': a_error,
            'c_error_percent': c_error,
            'geometry_valid': a_error < 5 and c_error < 5  # 5%误差阈值
        }

        return validation_results

    def calculate_max_interpenetration(self, cif_file_path: str) -> Dict:
        """
        主函数：计算CIF文件的最大互穿层数
        """
        print_ec(f"分析CIF文件: {cif_file_path}")

        # 1. 解析CIF文件
        cell_params = self.parse_cif_file(cif_file_path)
        if not cell_params:
            return {"error": "无法解析CIF文件"}

        print_ec("✓ CIF文件解析完成")
        print_ec(f"  晶胞参数: a={cell_params.get('_cell_length_a', 'N/A')} Å, "
              f"c={cell_params.get('_cell_length_c', 'N/A')} Å")

        # 2. 计算互穿层数
        try:
            interpenetration_results = self.calculate_interpenetration_number(cell_params)
        except ValueError as e:
            return {"error": str(e)}

        print_ec("✓ 互穿层数计算完成")
        print_ec(f"  计算值 N = {interpenetration_results['calculated_N']:.2f}")
        print_ec(f"  取整后 N = {interpenetration_results['rounded_N']}")

        # 3. 使用理想几何验证
        validation_results = self.validate_with_ideal_geometry(interpenetration_results)

        print_ec("✓ 理想几何验证完成")
        print_ec(f"  估算键长: {validation_results['bond_length_estimated']:.2f} Å")
        print_ec(f"  几何验证: {'通过' if validation_results['geometry_valid'] else '未通过'}")

        # 4. 综合结果
        final_results = {
            'file_analyzed': cif_file_path,
            'cell_parameters': cell_params,
            'interpenetration_calculation': interpenetration_results,
            'geometry_validation': validation_results,
            'recommended_N': interpenetration_results['rounded_N'],
            'confidence_level': 'high' if (
                    interpenetration_results['crystal_system_valid'] and
                    validation_results['geometry_valid']
            ) else 'medium'
        }

        return final_results


# 使用示例函数
def calculate_max_interpenetration_from_cif(cif_file_path: str) -> Dict:
    """
    简化接口函数：直接计算CIF文件的最大互穿层数
    """
    calculator = COFInterpenetrationCalculator()
    return calculator.calculate_max_interpenetration(cif_file_path)

