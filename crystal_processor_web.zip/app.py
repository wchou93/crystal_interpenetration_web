import traceback
import zipfile

from flask import Flask, render_template, request, send_file, flash, redirect, url_for, session, jsonify
import os
import uuid
from werkzeug.utils import secure_filename
import tempfile
import shutil

# 导入我们的晶体处理函数
from crystal_functions import *
from InterpenetrationCalculator import COFInterpenetrationCalculator

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'  # 必须设置才能使用session

# --- 新增：国际化配置 ---
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# 确保上传文件夹存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
print(f"INFO: Upload folder set to: {app.config['UPLOAD_FOLDER']}")

# --- 新增：翻译字典 ---
TRANSLATIONS = {
    'en': {
        'title': 'Crystal Structure Processing System',
        'nav_brand': 'Crystal Processor',
        'language': 'Language',
        'upload_title': 'Upload Crystal File',
        'select_file_label': 'Select CIF File',
        'file_format_note': 'Supported format: .cif (Max 16MB)',
        'process_type_label': 'Select Process Type',
        'supercell_btn': 'Generate Supercell',
        'interpenetration_btn': 'Expand Interpenetration',
        'supercell_params_title': 'Supercell Parameters',
        'multiplier_a': 'A-direction Multiplier',
        'multiplier_b': 'B-direction Multiplier',
        'multiplier_c': 'C-direction Multiplier',
        'interpenetration_params_title': 'Interpenetration Parameters',
        'num_layers_label': 'Number of Layers',
        'translation_vector_label': 'Translation Vector',
        'with_bonds_label': 'Retain Bond Information',
        'process_button': 'Start Processing',
        'supercell_desc_title': 'Generate Supercell',
        'supercell_desc': 'Translate and repeat the original unit cell in space to create a larger supercell structure. Suitable for studying properties like surfaces, interfaces, and defects.',
        'interpenetration_desc_title': 'Expand Interpenetration',
        'interpenetration_desc': 'Create multiple independent network structures that interpenetrate each other in space. Common in the study of porous materials like MOFs and COFs.',
        'result_title': 'Processing Complete',
        'file_processed': 'Your file has been successfully processed.',
        'supercell_complete': 'Supercell generation complete.',
        'interpenetration_complete': 'Interpenetration expansion complete.',
        'output_file_label': 'Output File:',
        'download_btn': 'Download File',
        'back_home_btn': 'Back to Home',
        'usage_notes_title': 'Usage Notes',
        'software_recom': 'Recommended Software',
        'important_notes': 'Important Notes',
        'error_no_file': 'No file selected.',
        'error_invalid_format': 'Only CIF file format is supported.',
        'error_illegal_name': 'Illegal filename, please rename and upload again.',
        'error_processing': 'An error occurred while processing the file: ',
        'error_download': 'An error occurred while downloading the file: ',
        'error_file_not_found': 'File not found or has been deleted: ',
        'error_illegal_path': 'Illegal file path!',
        'footer_text': '© 2023 Crystal Structure Processing System | A Tool for Materials Science Research',
        'use_custom_vector_label': 'Custom translation vector (Auto-search by default)',
        'reduce_cell_title': 'Reduce Cell to Primitive',
        'reduce_cell_desc': 'Convert the given crystal structure to its smallest primitive cell. Useful for simplifying the structure and identifying the fundamental repeating unit.',
        'reduce_cell_button': 'Reduce Cell',
        'reduce_cell_complete': 'Cell reduction complete.',
        'processing_options_title': 'Processing Options',
        'select_process_type_label': 'Select Processing Type',
        'reduce_cell_no_params': 'No additional parameters are needed for cell reduction. Simply click the "Process" button.',
        'all_params_title': 'Supercell + interpenetration + Reduce',
        'all_params_title_params': 'Parameter settings',
        'supercell_params_title2': 'Supercell matrix',
        'complete': 'Completed!',
        'files_generated': 'files generated',
        'individual_files_label': 'Individual Files',
        'download_all_btn': 'Download All (ZIP)',
    },
    'zh': {
        'title': '晶体结构处理系统',
        'nav_brand': '晶体处理器',
        'language': '语言',
        'upload_title': '上传晶体文件',
        'select_file_label': '选择CIF文件',
        'file_format_note': '支持格式：.cif (最大16MB)',
        'process_type_label': '选择处理类型',
        'supercell_btn': '晶体超胞生成（扩胞）',
        'interpenetration_btn': '拓展穿插层数（互穿）',
        'supercell_params_title': '超胞参数设置',
        'multiplier_a': 'A方向倍数',
        'multiplier_b': 'B方向倍数',
        'multiplier_c': 'C方向倍数',
        'interpenetration_params_title': '互穿参数设置',
        'num_layers_label': '互穿层数',
        'translation_vector_label': '平移向量',
        'with_bonds_label': '保留化学键信息',
        'process_button': '开始处理',
        'supercell_desc_title': '晶体超胞生成',
        'supercell_desc': '将原始晶胞在空间中按指定倍数进行平移重复，生成更大的超胞结构。适用于研究表面、界面、缺陷等性质。',
        'interpenetration_desc_title': '拓展穿插层数（互穿）',
        'interpenetration_desc': '创建多个独立的网络结构在空间中相互穿插，形成互穿结构。常见于MOF、COF等多孔材料的研究。',
        'result_title': '处理完成',
        'file_processed': '您的文件已成功处理。',
        'supercell_complete': '晶体超胞生成完成。',
        'interpenetration_complete': '拓展穿插层数完成。',
        'output_file_label': '输出文件：',
        'download_btn': '下载文件',
        'back_home_btn': '返回首页',
        'usage_notes_title': '使用说明',
        'software_recom': '软件推荐',
        'important_notes': '注意事项',
        'error_no_file': '没有选择文件。',
        'error_invalid_format': '只支持CIF文件格式。',
        'error_illegal_name': '文件名不合法，请重命名后上传。',
        'error_processing': '处理文件时出错: ',
        'error_download': '下载文件时出错: ',
        'error_file_not_found': '文件不存在或已被删除: ',
        'error_illegal_path': '非法的文件路径！',
        'footer_text': '© 2023 晶体结构处理系统 | 材料科学研究工具',
        'use_custom_vector_label': '自定义平移向量（默认自动识别）',
        'reduce_cell_title': '晶胞约化（缩胞）',
        'reduce_cell_desc': '将给定的晶体结构转换为其最小的原始晶胞。这有助于简化结构并识别最基本的重复单元。',
        'reduce_cell_button': '执行约化',
        'reduce_cell_complete': '晶胞约化完成。',
        'processing_options_title': '处理选项',
        'select_process_type_label': '选择处理类型',
        'reduce_cell_no_params': '晶胞约化不需要额外参数。只需点击“开始处理”按钮即可。',
        'supercell_params_title2': '超胞矩阵',
        'all_params_title': '扩胞+互穿+缩胞',
        'all_params_title_params': '参数设置',
        'complete': '处理完成。',
        'files_generated': '个文件已生成',
        'individual_files_label': '单个文件',
        'download_all_btn': '下载全部 (ZIP)',

    }
}


# --- 新增：获取当前语言的函数 ---
def get_locale():
    if 'language' in session:
        return session['language']
    return 'en'


# --- 新增：翻译函数 ---
def translate(key):
    lang = get_locale()
    return TRANSLATIONS.get(lang, {}).get(key, key)


# --- 新增：将翻译函数注册为模板全局函数 ---
@app.context_processor
def inject_translations():
    # --- 修正点：同时返回 _ 和 get_locale ---
    return dict(_=translate, get_locale=get_locale)


# --- 新增：语言切换路由 ---
@app.route('/set_language/<lang>')
def set_language(lang):
    if lang in TRANSLATIONS:
        session['language'] = lang
    return redirect(request.referrer or url_for('index'))


ALLOWED_EXTENSIONS = {'cif'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def process():
    if 'file' not in request.files:
        flash(translate('error_no_file'))
        return redirect(url_for('index'))

    file = request.files['file']
    if file.filename == '':
        flash(translate('error_no_file'))
        return redirect(url_for('index'))

    if not allowed_file(file.filename):
        flash(translate('error_invalid_format'))
        return redirect(url_for('index'))

    original_filename = secure_filename(file.filename)
    if not original_filename:
        flash(translate('error_illegal_name'))
        return redirect(url_for('index'))

    unique_id = str(uuid.uuid4())
    input_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{unique_id}_{original_filename}")
    file.save(input_path)
    print(f"DEBUG: Input file saved to: {input_path}")
    # 扩胞倍数矩阵
    scaling_matrix = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    try:
        # 1. 先获取并保存用户所有输入到session
        # 获取用户输入的互穿层数
        user_input_N = int(request.form.get('num_layers', 2))
        session['num_layers'] = user_input_N  # 保存用户输入的层数
        session['use_custom_vector'] = request.form.get('use_custom_vector', 'off')
        use_custom_vector = session['use_custom_vector'] == 'on'
        if use_custom_vector:
            session['tx'] = request.form.get('tx', 0.5)
            session['ty'] = request.form.get('ty', 0.5)
            session['tz'] = request.form.get('tz', 0.5)
            translation_vector = [
                float(session['tx']),
                float(session['ty']),
                float(session['tz'])
            ]
        else:
            translation_vector = None
        session['with_bonds'] = request.form.get('with_bonds', 'off')
        with_bonds = session['with_bonds'] == 'on'

        # 获取最佳互穿层数
        calculator = COFInterpenetrationCalculator()
        max_inter_result = calculator.calculate_max_interpenetration(input_path)
        max_possible_N = max_inter_result.get('recommended_N', 2)

        # 验证用户输入的层数
        if user_input_N > max_possible_N:
            # 提示用户输入超出最大层数
            lang = get_locale()
            if lang == "zh":
                flash(f"'{original_filename}'无法执行互穿层数为{user_input_N}的计算，请输入不大于{max_possible_N}的层数。")
            else:
                flash(f"'{original_filename}' Unable to perform calculations with {user_input_N} layers. Please enter a number of layers not exceeding {max_possible_N}.")
            os.remove(input_path)  # 清理临时文件
            return redirect(url_for('index'))

        # 创建临时目录保存所有结果
        unique_id = str(uuid.uuid4())
        output_dir = os.path.join(app.config['UPLOAD_FOLDER'], f"{unique_id}_outputs")
        os.makedirs(output_dir, exist_ok=True)

        # 存储所有生成的文件信息
        output_files = []
        base_name = os.path.splitext(original_filename)[0]
        # 读取结构
        structure = Structure.from_file(input_path)
        # 循环生成从2到最佳层数的所有结构
        for num_layers in range(2, user_input_N + 1):
            # 创建互穿结构
            contracted, result_info = create_interpenetrated_structure(
                structure,
                num_networks=num_layers,
                scaling_matrix=scaling_matrix,
                translation_vector=translation_vector
            )

            # 生成输出文件名
            output_filename = f"{base_name}_interpenetration_{num_layers}layers.cif"
            output_path = os.path.join(output_dir, output_filename)

            # 保存结构
            if with_bonds:
                calculation_bonds_optimized(contracted, output_path)
            else:
                contracted.to(filename=output_path, fmt="cif")

            output_files.append({
                'filename': output_filename,
                'path': output_path,
                'layers': num_layers
            })

        # 创建ZIP包
        zip_filename = f"{base_name}_interpenetration_results.zip"
        zip_path = os.path.join(app.config['UPLOAD_FOLDER'], zip_filename)

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_info in output_files:
                zipf.write(file_info['path'], arcname=file_info['filename'])

        session.pop("num_layers", None)
        session.pop("use_custom_vector", None)
        if use_custom_vector:
            session.pop("tx", None)
            session.pop("ty", None)
            session.pop("tz", None)
        session.pop("with_bonds", None)
        # 存储会话信息
        session['zip_file_path'] = zip_path
        session['zip_file_name'] = zip_filename
        session['output_files'] = output_files

        return render_template('result.html',
                               output_files=output_files,
                               zip_filename=zip_filename)
    except Exception as e:
        print(f"ERROR in /process route: {e}")
        traceback.print_exc()
        if os.path.exists(input_path):
            os.remove(input_path)
        flash(f"{translate('error_processing')}{str(e)}")
        return redirect(url_for('index'))


@app.route('/download/<path:filename>')
def download(filename):
    # 验证文件路径是否在允许的上传目录内
    if not os.path.abspath(filename).startswith(os.path.abspath(app.config['UPLOAD_FOLDER'])):
        flash(translate('error_illegal_path'))
        return redirect(url_for('index'))

    if os.path.exists(filename):
        try:
            # 获取文件名
            file_name = os.path.basename(filename)
            return send_file(filename, as_attachment=True, download_name=file_name)
        except Exception as e:
            flash(f"{translate('error_download')}{str(e)}")
            return redirect(url_for('index'))
    else:
        flash(f"{translate('error_file_not_found')}{filename}")
        return redirect(url_for('index'))


@app.route('/download_zip')
def download_zip():
    if 'zip_file_path' in session and 'zip_file_name' in session:
        zip_path = session['zip_file_path']
        zip_name = session['zip_file_name']

        if os.path.exists(zip_path):
            try:
                response = send_file(
                    zip_path,
                    as_attachment=True,
                    download_name=zip_name
                )

                # 下载后清理文件
                @response.call_on_close
                def cleanup():
                    if os.path.exists(zip_path):
                        os.remove(zip_path)
                    # 清理输出目录
                    output_dir = os.path.dirname(zip_path).replace('_outputs', '') + '_outputs'
                    if os.path.exists(output_dir):
                        shutil.rmtree(output_dir)
                    # 清除会话信息
                    session.pop('zip_file_path', None)
                    session.pop('zip_file_name', None)
                    session.pop('output_files', None)

                return response
            except Exception as e:
                flash(f"{translate('error_download')}{str(e)}")
                return redirect(url_for('index'))
        else:
            flash(f"{translate('error_file_not_found')}{zip_name}")
            return redirect(url_for('index'))
    else:
        flash(translate('error_file_not_found'))
        return redirect(url_for('index'))


@app.route('/calculate_recommended', methods=['POST'])
def calculate_recommended():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if not file or file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file format'}), 400

    try:
        # 创建临时文件
        with tempfile.NamedTemporaryFile(suffix='.cif', delete=False) as temp_file:
            file.save(temp_file.name)
            temp_path = temp_file.name

        # 计算推荐层数
        calculator = COFInterpenetrationCalculator()
        result = calculator.calculate_max_interpenetration(temp_path)

        # 清理临时文件
        os.unlink(temp_path)

        if 'recommended_N' in result:
            return jsonify({'recommended_N': result['recommended_N']})
        else:
            return jsonify({'recommended_N': 2})  # 默认值

    except Exception as e:
        return jsonify({'error': str(e), 'recommended_N': 2}), 500


if __name__ == '__main__':
    app.run(debug=True)
